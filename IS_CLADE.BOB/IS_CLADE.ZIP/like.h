double theta0=2.0;
double theta1=4.0;
int theta_points=1;
int theta_likelihood=1;
